package com.vinzx.xiterz

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private val bg = 0xFF10131C.toInt()
    private val accent = 0xFF20D6B5.toInt()
    private lateinit var announcement: TextView
    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(26,24,26,24); setBackgroundColor(bg)
    }
    private fun label(s:String,size:Float=20f)=TextView(this).apply { text=s;textSize=size;gravity=Gravity.CENTER;setTextColor(-1);setPadding(8,12,8,12) }
    private fun btn(s:String, action:()->Unit)=Button(this).apply {
        text=s;setTextColor(-1);setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));setOnClickListener{action()}
    }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);showLogin()}
    private fun showLogin(){
        val root=base();root.addView(label("VINZX XITERZ",30f));root.addView(label("LOGIN MEMBER",15f))
        val user=EditText(this).apply{hint="Username";setSingleLine();setTextColor(-1);setHintTextColor(0xFFAAAAAA.toInt())}
        val pass=EditText(this).apply{hint="Password";inputType=129;setSingleLine();setTextColor(-1);setHintTextColor(0xFFAAAAAA.toInt())}
        root.addView(user,LinearLayout.LayoutParams(-1,58));root.addView(pass,LinearLayout.LayoutParams(-1,58))
        announcement=label("Memuat informasi...",13f);root.addView(announcement)
        val status=label("",13f);root.addView(status)
        root.addView(btn("MASUK"){ 
            val u=user.text.toString().trim();val p=pass.text.toString()
            if(u.isEmpty()||p.isEmpty()){status.text="Username dan password wajib diisi";return@btn}
            status.text="Memeriksa akun ke server..."
            Thread {
                try {
                    val device=JSONObject().put("manufacturer",Build.MANUFACTURER).put("model",Build.MODEL)
                        .put("androidVersion",Build.VERSION.RELEASE)
                    val payload=JSONObject().put("data",JSONObject().put("username",u).put("password",p).put("device",device))
                    val response=post(BackendConfig.LOGIN_URL,payload)
                    val result=response.optJSONObject("result") ?: throw Exception(response.optJSONObject("error")?.optString("message") ?: "Login gagal")
                    runOnUiThread { status.text="Login berhasil";showHome(result.optString("username"),result.optString("role")) }
                }catch(e:Exception){runOnUiThread{status.text=e.message ?: "Tidak dapat terhubung ke server"}}
            }.start()
        })
        root.addView(label("Info perangkat dikirim saat login agar admin dapat melihat merek, model, dan versi Android.",11f))
        setContentView(root);loadAnnouncement()
    }
    private fun post(endpoint:String,payload:JSONObject):JSONObject{
        if(endpoint.contains("PROJECT_ID"))throw Exception("Backend belum dikonfigurasi. Isi Firebase Project ID terlebih dahulu.")
        val c=URL(endpoint).openConnection() as HttpURLConnection
        c.requestMethod="POST";c.connectTimeout=15000;c.readTimeout=15000;c.doOutput=true
        c.setRequestProperty("Content-Type","application/json")
        c.outputStream.use{it.write(payload.toString().toByteArray(Charsets.UTF_8))}
        val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream
        val body=stream.bufferedReader().use{it.readText()};c.disconnect()
        return JSONObject(body)
    }
    private fun loadAnnouncement(){
        Thread{try{
            val r=post(BackendConfig.ANNOUNCEMENT_URL,JSONObject().put("data",JSONObject())).optJSONObject("result")
            val text=if(r==null)"" else "${r.optString("status")}: ${r.optString("title")}\\n${r.optString("message")}"
            runOnUiThread{announcement.text=text}
        }catch(_:Exception){runOnUiThread{announcement.text="Informasi update akan tampil setelah backend aktif."}}}.start()
    }
    private fun showHome(username:String,role:String){
        val root=base();root.addView(label("VINZX XITERZ",29f));root.addView(label("Selamat datang, $username · $role",14f))
        root.addView(btn("AKTIFKAN PANEL"){enablePanel()})
        root.addView(btn("FREE FIRE BIASA"){launchGame("com.dts.freefireth")})
        root.addView(btn("FREE FIRE MAX"){launchGame("com.dts.freefiremax")})
        root.addView(btn("VINZX UPDATE"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(BackendConfig.WHATSAPP_URL)))})
        root.addView(label("Panel mengambang hanya menyediakan kontrol utilitas visual.",12f))
        setContentView(root)
    }
    private fun enablePanel(){
        if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")));Toast.makeText(this,"Izinkan tampil di atas aplikasi lalu kembali.",Toast.LENGTH_LONG).show();return}
        startService(Intent(this,FloatingPanelService::class.java))
    }
    private fun launchGame(pkg:String){
        val i=packageManager.getLaunchIntentForPackage(pkg)
        if(i!=null)startActivity(i) else startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id=$pkg")))
    }
}
