package com.vinzx.xiterz

object BackendConfig {
    // Ganti PROJECT_ID dengan Firebase Project ID milik Anda setelah deploy.
    const val LOGIN_URL = "https://us-central1-PROJECT_ID.cloudfunctions.net/loginWithKey"
    const val ANNOUNCEMENT_URL = "https://us-central1-PROJECT_ID.cloudfunctions.net/getAnnouncement"
    const val WHATSAPP_URL = "https://whatsapp.com/channel/0029Vb7L25dFMqrP53GOw51C"
}
