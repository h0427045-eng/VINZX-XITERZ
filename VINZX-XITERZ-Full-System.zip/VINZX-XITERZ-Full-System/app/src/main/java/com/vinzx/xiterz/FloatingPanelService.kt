package com.vinzx.xiterz

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*

class FloatingPanelService:Service(){
    private lateinit var wm:WindowManager
    private var panel:LinearLayout?=null
    private lateinit var params:WindowManager.LayoutParams
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onCreate(){super.onCreate();wm=getSystemService(WINDOW_SERVICE) as WindowManager;show()}
    private fun show(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,10,14,10);setBackgroundColor(0xEE182233.toInt())}
        val head=TextView(this).apply{text="VINZX XITERZ  ·  GESER";textSize=15f;setTextColor(-1);setPadding(8,10,8,14)}
        box.addView(head)
        val status=TextView(this).apply{text="PANEL AKTIF";setTextColor(0xFF20D6B5.toInt());setPadding(8,5,8,5)}
        box.addView(status)
        listOf("AIM DRAG","SENSITIVITAS","TOUCH SPEED","BOST FPS","SMOOTHING").forEach{n->
            box.addView(Switch(this).apply{text=n;setTextColor(-1);setOnCheckedChangeListener{_,on->status.text="$n: ${if(on)"ON" else "OFF"}"}})
        }
        val row=LinearLayout(this)
        row.addView(Button(this).apply{text="MINIM";setOnClickListener{box.removeAllViews();box.addView(Button(this@FloatingPanelService).apply{text="BUKA VINZX";setOnClickListener{stopSelf();startService(Intent(this@FloatingPanelService,FloatingPanelService::class.java))}})}})
        row.addView(Button(this).apply{text="TUTUP";setOnClickListener{stopSelf()}})
        box.addView(row)
        params=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
            .apply{gravity=Gravity.TOP or Gravity.START;x=35;y=160}
        head.setOnTouchListener(object:View.OnTouchListener{
            var sx=0;var sy=0;var tx=0f;var ty=0f
            override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.action){
                MotionEvent.ACTION_DOWN->{sx=params.x;sy=params.y;tx=e.rawX;ty=e.rawY;return true}
                MotionEvent.ACTION_MOVE->{params.x=sx+(e.rawX-tx).toInt();params.y=sy+(e.rawY-ty).toInt();wm.updateViewLayout(box,params);return true}
            };return false}
        })
        panel=box;wm.addView(box,params)
    }
    override fun onDestroy(){panel?.let{try{wm.removeView(it)}catch(_:Exception){}};panel=null;super.onDestroy()}
}
