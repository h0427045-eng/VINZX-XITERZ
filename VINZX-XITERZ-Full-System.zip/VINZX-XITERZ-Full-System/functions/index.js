const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineString } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");

admin.initializeApp();
const db = admin.firestore();
const ADMIN_EMAIL = defineString("ADMIN_EMAIL");

function requireAdmin(request) {
  if (!request.auth || !request.auth.token || request.auth.token.email !== ADMIN_EMAIL.value()) {
    throw new HttpsError("permission-denied", "Hanya admin utama yang diizinkan.");
  }
}
function cleanText(value, max = 80) {
  return String(value || "").trim().slice(0, max);
}
function passwordHash(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}
function durationMs(duration) {
  const map = { "1H":1, "3H":3, "7H":7, "15H":15, "30H":30 };
  if (duration === "PERMANEN" || duration === "DEV") return null;
  if (!map[duration]) throw new HttpsError("invalid-argument", "Durasi tidak valid.");
  return map[duration] * 60 * 60 * 1000;
}

exports.loginWithKey = onCall(async (request) => {
  const username = cleanText(request.data?.username, 48).toLowerCase();
  const password = String(request.data?.password || "");
  const device = request.data?.device || {};
  if (!username || !password || password.length > 128) {
    throw new HttpsError("invalid-argument", "Username dan password wajib diisi.");
  }
  const ref = db.collection("users").doc(username);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("unauthenticated", "Username atau password salah.");
  const user = snap.data();
  if (user.disabled) throw new HttpsError("permission-denied", "Akun dinonaktifkan admin.");
  const actual = Buffer.from(passwordHash(password, user.salt), "hex");
  const expected = Buffer.from(user.passwordHash, "hex");
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) {
    throw new HttpsError("unauthenticated", "Username atau password salah.");
  }
  const now = Date.now();
  if (user.expiresAt && now > user.expiresAt) {
    throw new HttpsError("permission-denied", "Masa aktif akun sudah habis.");
  }
  const deviceInfo = {
    manufacturer: cleanText(device.manufacturer, 60),
    model: cleanText(device.model, 80),
    androidVersion: cleanText(device.androidVersion, 30),
    lastSeenAt: now
  };
  await ref.update({ lastLoginAt: now, lastDevice: deviceInfo });
  await db.collection("loginEvents").add({ username, device: deviceInfo, createdAt: now });
  return { ok:true, username, role:user.role || "USER", expiresAt:user.expiresAt || null };
});

exports.getAnnouncement = onCall(async () => {
  const snap = await db.collection("announcements").doc("current").get();
  if (!snap.exists) return { title:"Informasi VINZX", message:"Belum ada pengumuman.", status:"INFO", updatedAt:null };
  const a = snap.data();
  return { title:a.title || "Informasi VINZX", message:a.message || "", status:a.status || "INFO", updatedAt:a.updatedAt || null };
});

exports.adminListUsers = onCall(async (request) => {
  requireAdmin(request);
  const snap = await db.collection("users").orderBy("createdAt", "desc").limit(300).get();
  return { users:snap.docs.map(d => {
    const u = d.data();
    return { username:d.id, role:u.role || "USER", duration:u.duration || "", expiresAt:u.expiresAt || null,
      disabled:!!u.disabled, createdAt:u.createdAt || null, lastLoginAt:u.lastLoginAt || null,
      lastDevice:u.lastDevice || null };
  }) };
});

exports.adminCreateUser = onCall(async (request) => {
  requireAdmin(request);
  const username = cleanText(request.data?.username, 48).toLowerCase();
  const password = String(request.data?.password || "");
  const duration = cleanText(request.data?.duration, 16).toUpperCase();
  const role = duration === "DEV" ? "DEV" : "USER";
  if (!/^[a-z0-9._-]{3,48}$/.test(username)) throw new HttpsError("invalid-argument", "Username 3-48 karakter: huruf kecil, angka, titik, _ atau -.");
  if (password.length < 8 || password.length > 128) throw new HttpsError("invalid-argument", "Password harus 8-128 karakter.");
  const ms = durationMs(duration);
  const ref = db.collection("users").doc(username);
  if ((await ref.get()).exists) throw new HttpsError("already-exists", "Username sudah digunakan.");
  const salt = crypto.randomBytes(16).toString("hex");
  const now = Date.now();
  await ref.create({ salt, passwordHash:passwordHash(password, salt), role, duration,
    expiresAt:ms === null ? null : now + ms, disabled:false, createdAt:now,
    createdBy:request.auth.token.email });
  return { ok:true, username };
});

exports.adminSetUserDisabled = onCall(async (request) => {
  requireAdmin(request);
  const username = cleanText(request.data?.username, 48).toLowerCase();
  if (!username) throw new HttpsError("invalid-argument", "Username wajib.");
  await db.collection("users").doc(username).update({ disabled:!!request.data.disabled });
  return { ok:true };
});

exports.adminDeleteUser = onCall(async (request) => {
  requireAdmin(request);
  const username = cleanText(request.data?.username, 48).toLowerCase();
  if (!username) throw new HttpsError("invalid-argument", "Username wajib.");
  await db.collection("users").doc(username).delete();
  return { ok:true };
});

exports.adminPublishAnnouncement = onCall(async (request) => {
  requireAdmin(request);
  const title = cleanText(request.data?.title, 100);
  const message = cleanText(request.data?.message, 1000);
  const status = cleanText(request.data?.status, 30).toUpperCase();
  if (!title || !message) throw new HttpsError("invalid-argument", "Judul dan pesan wajib diisi.");
  await db.collection("announcements").doc("current").set({
    title, message, status:status || "INFO", updatedAt:Date.now(), updatedBy:request.auth.token.email
  });
  return { ok:true };
});
