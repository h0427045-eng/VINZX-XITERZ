// Isi dari Firebase Console > Project settings > General > Your apps (Web app).
// Jangan masukkan service-account private key di file ini.
window.VINZX_FIREBASE_CONFIG = {
  apiKey: "ISI_API_KEY",
  authDomain: "ISI_PROJECT_ID.firebaseapp.com",
  projectId: "ISI_PROJECT_ID",
  appId: "ISI_APP_ID"
};
