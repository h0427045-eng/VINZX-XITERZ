# VINZX XITERZ — APK + Admin Panel + Backend

Paket starter ini berisi:
- Aplikasi Android (Kotlin): login server, HOME, peluncur Free Fire biasa/MAX, tautan WhatsApp, dan floating utility panel.
- Admin Panel web dark: login admin tunggal, buat akun pengguna, pilih durasi 1H/3H/7H/15H/30H/PERMANEN/DEV, lihat perangkat, nonaktifkan/hapus akun, dan kirim pengumuman.
- Firebase Cloud Functions + Firestore Rules.

## PENTING
1. Admin Panel tidak memiliki password bawaan. Buat satu akun admin di Firebase Authentication (Email/Password), lalu isi email itu pada konfigurasi `ADMIN_EMAIL` fungsi.
2. Firebase project harus milik Anda. Jangan bagikan private key/service-account JSON.
3. Data perangkat (merek/model/versi Android) dikirim saat login untuk ditampilkan di Admin Panel. Beri tahu pengguna dan minta persetujuan sesuai aturan privasi yang berlaku.
4. Tombol/opsi floating panel adalah utilitas visual. Tidak mengubah memori/gameplay Free Fire, tidak memberikan aimbot/ESP, dan tidak menjanjikan perubahan FPS atau sensitivitas game.
5. APK belum bisa login sungguhan sebelum URL Cloud Functions dan konfigurasi Firebase Admin Panel diisi.

## A. Buat Firebase project
1. Buka https://console.firebase.google.com/ dan buat project `VINZX-XITERZ`.
2. Aktifkan Firestore Database.
3. Authentication > Sign-in method > aktifkan Email/Password.
4. Buat SATU akun admin di Authentication > Users. Simpan email dan password admin dengan aman.
5. Daftarkan Web App di Project settings > General > Your apps, lalu salin Firebase config ke `admin/config.js`.
6. Catat Project ID. Deploy Functions dengan Firebase CLI dari komputer atau layanan cloud yang mendukung Node.js. Build APK bisa memakai GitHub Actions.

## B. Konfigurasi backend
Masuk ke folder `functions`, jalankan `npm install`, lalu dari root:
- `firebase login`
- `firebase use --add` (pilih project Anda)
- Set parameter `ADMIN_EMAIL` saat deploy pertama kali jika diminta.
- `firebase deploy --only firestore:rules,functions,hosting`

Deploy membutuhkan Firebase CLI dan Node.js. File `firebase.json` dan `.firebaserc.example` disertakan.

## C. Konfigurasi URL backend Android
Setelah Functions deploy, salin URL endpoint `loginWithKey` dan `getAnnouncement` dari output Firebase ke:
`app/src/main/java/com/vinzx/xiterz/BackendConfig.kt`

Format callable endpoint:
`https://us-central1-PROJECT_ID.cloudfunctions.net/loginWithKey`
dan
`https://us-central1-PROJECT_ID.cloudfunctions.net/getAnnouncement`

## D. Admin Panel
Isi `admin/config.js` dengan Firebase web config Anda. Hosting dapat dipakai lewat Firebase Hosting setelah `firebase deploy --only hosting`.
Login admin memakai akun Firebase Authentication yang dibuat di langkah A. Fungsi server hanya menerima email admin yang sama dengan `ADMIN_EMAIL`.

## E. Build APK
Push folder proyek ini ke repository GitHub. Workflow `.github/workflows/android.yml` membangun APK debug. Buka tab Actions, jalankan workflow, lalu unduh artifact `VINZX-XITERZ-debug-apk`.

## Model akun
- 1H, 3H, 7H, 15H, 30H: masa aktif dihitung sejak akun dibuat atau diaktifkan.
- PERMANEN: tidak kedaluwarsa.
- DEV: role developer khusus; masa aktif juga mengikuti waktu yang dipilih saat dibuat (default permanen). Hak DEV pada starter ini hanya penanda role dan tidak membuka akses ke fitur berbahaya.

## Catatan keamanan
- Password pengguna di-hash dengan scrypt di server.
- Firestore client rules menolak akses langsung ke koleksi akun.
- Semua operasi admin dilakukan melalui Cloud Functions dengan pemeriksaan email admin.
- Untuk produksi, tambahkan rate limiting, App Check, backup, pemantauan biaya, dan kebijakan privasi.
